<?php die("Access denied");
