PSHOW UPSELL CHANGELOG
==========

v1.1 - 18.12.2020 - big updates
-----
* added new functionalities to create better cross-sell products
* improved performance
* fixed reported bugs

v1.0 - 01.06.2020
-----
* initial version of the module
