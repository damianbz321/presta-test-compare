<?php

use PHPUnit\Framework\TestCase;

class TestTest extends TestCase
{

    public function test()
    {
        $this->assertEquals(1, 1);
    }

}
