<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pshowupsell}prestashop>displayshoppingcartfooter_5316226bf409bd2814331fc97ee2b7ae'] = 'To się opłaca: ';
